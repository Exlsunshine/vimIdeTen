alias rn='react-native'
alias rns='react-native start'
alias rnlink='react-native link'

alias rnand='react-native run-android'
alias rnios='react-native run-ios'
alias rnios4s='react-native run-ios --simulator "iPhone 4s"'
alias rnios5='react-native run-ios --simulator "iPhone 5"'
alias rnios5s='react-native run-ios --simulator "iPhone 5s"'
alias rnios6='react-native run-ios --simulator "iPhone 6"'
alias rnios6s='react-native run-ios --simulator "iPhone 6s"'

alias rnland='react-native log-android'
alias rnlios='react-native log-ios'
